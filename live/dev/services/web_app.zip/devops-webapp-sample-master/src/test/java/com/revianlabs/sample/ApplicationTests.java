package com.revianlabs.sample;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTests {
}
